"use client"

import { Badge } from "@/components/ui/badge"
import { Clock, ExternalLink } from "lucide-react"
import Link from "next/link"

interface StockNewsProps {
  stockCode: string
}

export function StockNews({ stockCode }: StockNewsProps) {
  // 根据股票代码获取不同的模拟新闻数据
  const getNewsData = () => {
    if (stockCode === "600519") {
      return [
        {
          id: 1,
          title: "贵州茅台2023年营收突破1250亿元，净利润同比增长13.1%",
          time: "2024-03-28 19:30",
          source: "公司公告",
          category: "财报",
          tags: ["业绩", "白酒", "财报"],
          isHot: true,
        },
        {
          id: 2,
          title: "贵州茅台发布2024年一季度业绩预告，预计净利润增长10%以上",
          time: "2024-04-10 09:15",
          source: "公司公告",
          category: "业绩预告",
          tags: ["业绩预告", "白酒", "一季报"],
          isHot: true,
        },
        {
          id: 3,
          title: "贵州茅台推出新品茅台1935，定位高端市场",
          time: "2024-04-05 14:20",
          source: "证券时报",
          category: "产品",
          tags: ["新品", "白酒", "高端"],
          isHot: false,
        },
        {
          id: 4,
          title: "机构调研：贵州茅台未来三年产能规划及市场策略",
          time: "2024-04-02 10:45",
          source: "券商研报",
          category: "调研",
          tags: ["产能", "策略", "研报"],
          isHot: false,
        },
        {
          id: 5,
          title: "贵州茅台董事长表示：将加大数字化转型力度，提升生产效率",
          time: "2024-03-30 16:30",
          source: "公司新闻",
          category: "战略",
          tags: ["数字化", "转型", "效率"],
          isHot: false,
        },
        {
          id: 6,
          title: "贵州茅台获评2023年度最受投资者尊敬上市公司",
          time: "2024-03-25 11:20",
          source: "市场新闻",
          category: "荣誉",
          tags: ["荣誉", "投资者关系"],
          isHot: false,
        },
      ]
    } else if (stockCode === "300750") {
      return [
        {
          id: 1,
          title: "宁德时代与大众汽车签署战略合作协议，共同开发新一代电池技术",
          time: "2024-04-12 08:30",
          source: "公司公告",
          category: "合作",
          tags: ["大众", "电池技术", "战略合作"],
          isHot: true,
        },
        {
          id: 2,
          title: "宁德时代发布第六代CTP技术，能量密度提升20%",
          time: "2024-04-08 10:15",
          source: "公司公告",
          category: "技术",
          tags: ["CTP", "能量密度", "技术创新"],
          isHot: true,
        },
        {
          id: 3,
          title: "宁德时代2023年营收4285亿元，净利润同比增长10.3%",
          time: "2024-03-30 19:45",
          source: "公司公告",
          category: "财报",
          tags: ["业绩", "财报", "增长"],
          isHot: false,
        },
        {
          id: 4,
          title: "宁德时代印尼工厂正式投产，海外布局加速",
          time: "2024-03-25 14:30",
          source: "公司新闻",
          category: "产能",
          tags: ["印尼", "海外", "产能"],
          isHot: false,
        },
        {
          id: 5,
          title: "宁德时代与特斯拉续签长期供货协议，合作关系进一步深化",
          time: "2024-03-20 09:10",
          source: "市场新闻",
          category: "合作",
          tags: ["特斯拉", "供应链", "合作"],
          isHot: false,
        },
        {
          id: 6,
          title: "宁德时代加大研发投入，2023年研发支出超200亿元",
          time: "2024-03-15 11:25",
          source: "研究报告",
          category: "研发",
          tags: ["研发", "创新", "投入"],
          isHot: false,
        },
      ]
    } else if (stockCode === "601318") {
      return [
        {
          id: 1,
          title: "中国平安2023年净利润1435亿元，同比增长3.2%",
          time: "2024-03-21 19:30",
          source: "公司公告",
          category: "财报",
          tags: ["业绩", "保险", "财报"],
          isHot: true,
        },
        {
          id: 2,
          title: "中国平安推出平安智慧养老战略，布局养老产业",
          time: "2024-04-10 10:45",
          source: "公司公告",
          category: "战略",
          tags: ["养老", "战略", "布局"],
          isHot: true,
        },
        {
          id: 3,
          title: "中国平安寿险新单保费同比增长15.3%，市场份额持续提升",
          time: "2024-04-05 15:20",
          source: "行业报告",
          category: "业务",
          tags: ["寿险", "保费", "市场份额"],
          isHot: false,
        },
        {
          id: 4,
          title: "中国平安科技投入持续加大，AI应用场景超过300个",
          time: "2024-03-28 11:30",
          source: "公司新闻",
          category: "科技",
          tags: ["AI", "科技", "创新"],
          isHot: false,
        },
        {
          id: 5,
          title: "中国平安获批设立养老金管理公司，养老金融布局加速",
          time: "2024-03-15 09:20",
          source: "监管公告",
          category: "业务",
          tags: ["养老金", "金融", "布局"],
          isHot: false,
        },
        {
          id: 6,
          title: "中国平安董事长表示：将持续深化金融+医疗战略协同",
          time: "2024-03-10 14:15",
          source: "媒体采访",
          category: "战略",
          tags: ["金融", "医疗", "协同"],
          isHot: false,
        },
      ]
    } else {
      return [
        {
          id: 1,
          title: "暂无相关新闻",
          time: "",
          source: "",
          category: "",
          tags: [],
          isHot: false,
        },
      ]
    }
  }

  const newsData = getNewsData()

  return (
    <div className="space-y-4">
      {newsData.map((item) => (
        <Link
          href={`/news/${item.id}`}
          key={item.id}
          className="block border rounded-lg p-3 hover:bg-muted/50 transition-colors"
        >
          <div className="flex items-start justify-between">
            <h3 className="font-medium">
              {item.isHot && (
                <Badge variant="secondary" className="mr-2 bg-red-100 text-red-700 hover:bg-red-100">
                  热门
                </Badge>
              )}
              {item.title}
            </h3>
            <ExternalLink className="h-4 w-4 text-muted-foreground flex-shrink-0 ml-2" />
          </div>

          <div className="flex items-center mt-2 text-sm text-muted-foreground">
            <Clock className="h-3.5 w-3.5 mr-1" />
            <span>{item.time}</span>
            <span className="mx-2">·</span>
            <span>{item.source}</span>
            {item.category && (
              <>
                <span className="mx-2">·</span>
                <Badge variant="outline" className="text-xs font-normal">
                  {item.category}
                </Badge>
              </>
            )}
          </div>

          <div className="flex items-center mt-2 flex-wrap gap-1">
            {item.tags.map((tag, idx) => (
              <Badge key={idx} variant="outline" className="text-xs font-normal">
                {tag}
              </Badge>
            ))}
          </div>
        </Link>
      ))}
    </div>
  )
}

