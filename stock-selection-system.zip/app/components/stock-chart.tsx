"use client"

import { useEffect, useRef } from "react"

interface StockChartProps {
  negative?: boolean
}

export function StockChart({ negative = false }: StockChartProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas dimensions
    const dpr = window.devicePixelRatio || 1
    const rect = canvas.getBoundingClientRect()
    canvas.width = rect.width * dpr
    canvas.height = rect.height * dpr
    ctx.scale(dpr, dpr)

    // Generate random data points
    const points = 20
    const data = Array.from({ length: points }, () => Math.random() * 30 + (negative ? 50 : 70))

    // If negative trend, make the line go down overall
    if (negative) {
      data.sort((a, b) => b - a)
    }

    // Draw the line
    const width = rect.width
    const height = rect.height
    const stepX = width / (points - 1)

    ctx.beginPath()
    ctx.moveTo(0, height - (data[0] / 100) * height)

    for (let i = 1; i < points; i++) {
      ctx.lineTo(i * stepX, height - (data[i] / 100) * height)
    }

    ctx.strokeStyle = negative ? "#ef4444" : "#22c55e"
    ctx.lineWidth = 2
    ctx.stroke()

    // Fill area under the line
    ctx.lineTo(width, height)
    ctx.lineTo(0, height)
    ctx.closePath()

    const gradient = ctx.createLinearGradient(0, 0, 0, height)
    if (negative) {
      gradient.addColorStop(0, "rgba(239, 68, 68, 0.2)")
      gradient.addColorStop(1, "rgba(239, 68, 68, 0)")
    } else {
      gradient.addColorStop(0, "rgba(34, 197, 94, 0.2)")
      gradient.addColorStop(1, "rgba(34, 197, 94, 0)")
    }

    ctx.fillStyle = gradient
    ctx.fill()
  }, [negative])

  return <canvas ref={canvasRef} className="h-full w-full" />
}

