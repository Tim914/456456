"use client"

import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { FileText, ThumbsUp, MessageSquare, Calendar } from "lucide-react"

interface StockAnalysisProps {
  stockCode: string
}

export function StockAnalysis({ stockCode }: StockAnalysisProps) {
  // 根据股票代码获取不同的模拟分析报告数据
  const getAnalysisData = () => {
    if (stockCode === "600519") {
      return [
        {
          id: 1,
          title: "贵州茅台：高端白酒龙头，业绩稳健增长",
          author: "张明",
          organization: "中信证券",
          date: "2024-04-10",
          rating: "买入",
          targetPrice: "2100.00",
          summary:
            "公司作为高端白酒龙头，品牌价值持续提升，渠道改革成效显著，产品结构持续优化。预计2024年营收增长12-15%，净利润增长13-16%。维持买入评级，目标价2100元。",
          likes: 156,
          comments: 32,
        },
        {
          id: 2,
          title: "贵州茅台深度报告：渠道变革驱动新一轮增长",
          author: "李强",
          organization: "国泰君安",
          date: "2024-04-05",
          rating: "增持",
          targetPrice: "2050.00",
          summary:
            "公司渠道改革持续深化，直营比例提升，有望带来盈利能力进一步提升。同时，产品结构调整为高端化发展奠定基础。预计未来三年复合增长率维持在12%以上。给予增持评级。",
          likes: 124,
          comments: 28,
        },
        {
          id: 3,
          title: "白酒行业专题：高端白酒竞争格局分析",
          author: "王芳",
          organization: "华泰证券",
          date: "2024-03-28",
          rating: "买入",
          targetPrice: "2150.00",
          summary:
            "高端白酒市场集中度持续提升，贵州茅台市场份额稳步增长。在消费升级背景下，高端白酒需求韧性强，茅台作为行业龙头，品牌溢价能力强，估值有望进一步提升。",
          likes: 98,
          comments: 21,
        },
        {
          id: 4,
          title: "贵州茅台2023年报点评：业绩符合预期，股息率提升",
          author: "赵刚",
          organization: "海通证券",
          date: "2024-03-25",
          rating: "买入",
          targetPrice: "2080.00",
          summary:
            "公司2023年业绩符合市场预期，营收增长12.3%，净利润增长13.1%。分红比例提升至60%，股息率达到1.8%，彰显公司回报股东决心。看好公司长期发展，维持买入评级。",
          likes: 87,
          comments: 19,
        },
      ]
    } else if (stockCode === "300750") {
      return [
        {
          id: 1,
          title: "宁德时代：全球动力电池龙头，技术优势显著",
          author: "陈明",
          organization: "中金公司",
          date: "2024-04-12",
          rating: "买入",
          targetPrice: "240.00",
          summary:
            "公司作为全球动力电池龙头，市场份额持续提升，技术优势显著。CTP技术迭代加速，有望进一步降低成本、提升能量密度。海外扩张顺利，全球化布局加速。维持买入评级。",
          likes: 178,
          comments: 42,
        },
        {
          id: 2,
          title: "宁德时代深度报告：钠离子电池商业化前景分析",
          author: "刘强",
          organization: "国信证券",
          date: "2024-04-08",
          rating: "增持",
          targetPrice: "230.00",
          summary:
            "公司钠离子电池技术取得突破，有望在2024年实现规模化商业应用。钠离子电池在储能和低端电动车领域具有成本优势，将成为公司新的增长点。给予增持评级。",
          likes: 145,
          comments: 35,
        },
        {
          id: 3,
          title: "新能源汽车产业链专题：动力电池竞争格局分析",
          author: "张芳",
          organization: "招商证券",
          date: "2024-03-30",
          rating: "买入",
          targetPrice: "250.00",
          summary:
            "全球动力电池市场集中度高，宁德时代、LG新能源、三星SDI三足鼎立。宁德时代凭借技术优势和成本控制能力，市场份额有望进一步提升。看好公司长期发展前景。",
          likes: 112,
          comments: 27,
        },
        {
          id: 4,
          title: "宁德时代2023年报点评：业绩符合预期，研发投入加大",
          author: "李刚",
          organization: "广发证券",
          date: "2024-03-25",
          rating: "买入",
          targetPrice: "235.00",
          summary:
            "公司2023年业绩符合预期，营收增长22.6%，净利润增长10.3%。研发投入超200亿元，占营收比例4.7%，技术领先优势持续巩固。全球化布局加速，海外收入占比提升至35%。维持买入评级。",
          likes: 95,
          comments: 23,
        },
      ]
    } else if (stockCode === "601318") {
      return [
        {
          id: 1,
          title: "中国平安：金融科技转型加速，寿险业务企稳回升",
          author: "王明",
          organization: "中信建投",
          date: "2024-04-10",
          rating: "买入",
          targetPrice: "58.00",
          summary:
            "公司金融科技转型成效显著，科技投入持续加大，AI应用场景超300个。寿险业务企稳回升，新单保费同比增长15.3%。金融+医疗生态协同效应增强。维持买入评级。",
          likes: 132,
          comments: 29,
        },
        {
          id: 2,
          title: "中国平安深度报告：养老金融布局及前景分析",
          author: "张强",
          organization: "华泰证券",
          date: "2024-04-05",
          rating: "增持",
          targetPrice: "55.00",
          summary:
            "公司养老金融布局加速，获批设立养老金管理公司，推出平安智慧养老战略。在人口老龄化背景下，养老金融市场空间广阔，公司有望充分受益。给予增持评级。",
          likes: 108,
          comments: 24,
        },
        {
          id: 3,
          title: "保险行业专题：寿险业务复苏与估值修复",
          author: "李芳",
          organization: "国泰君安",
          date: "2024-03-28",
          rating: "买入",
          targetPrice: "60.00",
          summary:
            "保险行业寿险业务复苏明显，代理人队伍质量提升，新单价值率改善。中国平安作为行业龙头，受益于行业复苏，估值有望修复。看好公司长期发展前景。",
          likes: 87,
          comments: 19,
        },
        {
          id: 4,
          title: "中国平安2023年报点评：业绩稳健，股息率吸引力强",
          author: "赵刚",
          organization: "申万宏源",
          date: "2024-03-22",
          rating: "买入",
          targetPrice: "56.00",
          summary:
            "公司2023年业绩稳健，营收增长5.8%，净利润增长3.2%。分红比例维持在30%以上，股息率达到4.5%，具有较强吸引力。科技赋能金融业务成效显著。维持买入评级。",
          likes: 76,
          comments: 17,
        },
      ]
    } else {
      return [
        {
          id: 1,
          title: "暂无相关分析报告",
          author: "",
          organization: "",
          date: "",
          rating: "",
          targetPrice: "",
          summary: "",
          likes: 0,
          comments: 0,
        },
      ]
    }
  }

  const analysisData = getAnalysisData()

  return (
    <div className="space-y-4">
      {analysisData.map((item) => (
        <Card key={item.id} className="overflow-hidden">
          <CardContent className="p-4">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="font-medium">{item.title}</h3>
                <div className="flex items-center mt-2 text-sm">
                  {item.rating && (
                    <Badge className="mr-2 bg-green-100 text-green-700 hover:bg-green-100">{item.rating}</Badge>
                  )}
                  {item.targetPrice && (
                    <Badge variant="outline" className="mr-2">
                      目标价: {item.targetPrice}
                    </Badge>
                  )}
                  <Calendar className="h-3.5 w-3.5 mr-1 text-muted-foreground" />
                  <span className="text-muted-foreground">{item.date}</span>
                </div>
              </div>
              {item.organization && <Badge variant="secondary">{item.organization}</Badge>}
            </div>

            {item.summary && <div className="mt-3 text-sm text-muted-foreground">{item.summary}</div>}

            <div className="mt-4 flex items-center justify-between">
              {item.author && (
                <div className="flex items-center">
                  <Avatar className="h-6 w-6 mr-2">
                    <AvatarImage src={`/placeholder.svg?height=24&width=24`} alt={item.author} />
                    <AvatarFallback>{item.author.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <span className="text-sm">{item.author}</span>
                </div>
              )}

              <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                <div className="flex items-center">
                  <FileText className="h-3.5 w-3.5 mr-1" />
                  <span>完整报告</span>
                </div>
                {item.likes > 0 && (
                  <div className="flex items-center">
                    <ThumbsUp className="h-3.5 w-3.5 mr-1" />
                    <span>{item.likes}</span>
                  </div>
                )}
                {item.comments > 0 && (
                  <div className="flex items-center">
                    <MessageSquare className="h-3.5 w-3.5 mr-1" />
                    <span>{item.comments}</span>
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

