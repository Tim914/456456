import Link from "next/link"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  ArrowLeft,
  ArrowUp,
  BarChart3,
  Download,
  Eye,
  Search,
  Share2,
  Star,
  TrendingUp,
  Users,
  Zap,
} from "lucide-react"
import { KLineChart } from "@/app/components/k-line-chart"
import { StockInfo } from "@/app/components/stock-info"
import { StockNews } from "@/app/components/stock-news"
import { KnowledgeGraph } from "@/app/components/knowledge-graph"
import { StockAnalysis } from "@/app/components/stock-analysis"

export default function StockDetailPage({ params }: { params: { code: string } }) {
  // 这里可以根据股票代码获取真实数据
  // 这里使用模拟数据
  const stockData = {
    code: params.code,
    name:
      params.code === "600519"
        ? "贵州茅台"
        : params.code === "300750"
          ? "宁德时代"
          : params.code === "601318"
            ? "中国平安"
            : "未知股票",
    price:
      params.code === "600519"
        ? "1892.50"
        : params.code === "300750"
          ? "187.65"
          : params.code === "601318"
            ? "48.92"
            : "0.00",
    change:
      params.code === "600519"
        ? "+2.5%"
        : params.code === "300750"
          ? "+3.8%"
          : params.code === "601318"
            ? "+1.2%"
            : "0.0%",
    volume: "2.34M",
    marketCap:
      params.code === "600519"
        ? "23,782亿"
        : params.code === "300750"
          ? "4,382亿"
          : params.code === "601318"
            ? "8,945亿"
            : "0亿",
    pe: params.code === "600519" ? "32.5" : params.code === "300750" ? "45.8" : params.code === "601318" ? "8.2" : "0",
    industry:
      params.code === "600519"
        ? "白酒"
        : params.code === "300750"
          ? "新能源"
          : params.code === "601318"
            ? "保险"
            : "未知",
  }

  return (
    <div className="flex min-h-screen w-full flex-col">
      <header className="sticky top-0 z-50 flex h-16 items-center gap-4 border-b bg-background px-4 md:px-6">
        <Link href="/" className="flex items-center gap-2 font-semibold">
          <TrendingUp className="h-6 w-6 text-primary" />
          <span className="text-xl">来财智能选股系统</span>
        </Link>
        <div className="ml-auto flex items-center gap-4">
          <form className="relative hidden md:block">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <input
              type="search"
              placeholder="搜索股票..."
              className="rounded-md border border-input bg-background pl-8 pr-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            />
          </form>
          <Button variant="outline" size="sm" className="hidden md:flex">
            登录
          </Button>
          <Button size="sm" className="hidden md:flex">
            注册
          </Button>
          <Avatar className="h-9 w-9">
            <AvatarImage src="/placeholder.svg?height=36&width=36" alt="Avatar" />
            <AvatarFallback>用户</AvatarFallback>
          </Avatar>
        </div>
      </header>

      <div className="flex items-center px-4 py-2 border-b">
        <Button variant="ghost" size="sm" asChild>
          <Link href="/">
            <ArrowLeft className="mr-2 h-4 w-4" />
            返回
          </Link>
        </Button>
        <div className="ml-4">
          <span className="text-sm text-muted-foreground">股票详情</span>
        </div>
      </div>

      <main className="flex-1 p-4 md:p-6">
        <div className="grid gap-6 md:grid-cols-3">
          <div className="md:col-span-2">
            <Card className="mb-6">
              <CardHeader className="pb-2">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <CardTitle className="text-2xl">{stockData.name}</CardTitle>
                      <Badge variant="outline">{stockData.code}</Badge>
                      <Badge variant="secondary" className="bg-blue-100 text-blue-700 hover:bg-blue-100">
                        {stockData.industry}
                      </Badge>
                    </div>
                    <CardDescription className="mt-1">上海证券交易所</CardDescription>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="icon">
                      <Star className="h-4 w-4" />
                    </Button>
                    <Button variant="outline" size="icon">
                      <Share2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col md:flex-row md:items-end justify-between mb-4">
                  <div>
                    <div className="text-4xl font-bold">{stockData.price}</div>
                    <div className="flex items-center text-green-500 mt-1">
                      <ArrowUp className="mr-1 h-4 w-4" />
                      {stockData.change} <span className="text-muted-foreground ml-2">今日</span>
                    </div>
                  </div>
                  <div className="flex gap-2 mt-4 md:mt-0">
                    <Button>买入</Button>
                    <Button variant="outline">卖出</Button>
                  </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                  <div className="border rounded-md p-2">
                    <div className="text-sm text-muted-foreground">成交量</div>
                    <div className="font-medium">{stockData.volume}</div>
                  </div>
                  <div className="border rounded-md p-2">
                    <div className="text-sm text-muted-foreground">市值</div>
                    <div className="font-medium">{stockData.marketCap}</div>
                  </div>
                  <div className="border rounded-md p-2">
                    <div className="text-sm text-muted-foreground">市盈率</div>
                    <div className="font-medium">{stockData.pe}</div>
                  </div>
                  <div className="border rounded-md p-2">
                    <div className="text-sm text-muted-foreground">52周区间</div>
                    <div className="font-medium">1680 - 1950</div>
                  </div>
                </div>

                <Tabs defaultValue="day">
                  <div className="flex justify-between items-center mb-4">
                    <TabsList>
                      <TabsTrigger value="day">日K</TabsTrigger>
                      <TabsTrigger value="week">周K</TabsTrigger>
                      <TabsTrigger value="month">月K</TabsTrigger>
                      <TabsTrigger value="quarter">季K</TabsTrigger>
                      <TabsTrigger value="year">年K</TabsTrigger>
                    </TabsList>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        <Download className="mr-2 h-4 w-4" />
                        导出
                      </Button>
                      <Button variant="outline" size="sm">
                        <Eye className="mr-2 h-4 w-4" />
                        指标
                      </Button>
                    </div>
                  </div>

                  <TabsContent value="day" className="mt-0">
                    <div className="h-[400px] border rounded-md p-2">
                      <KLineChart timeframe="day" stockCode={params.code} />
                    </div>
                  </TabsContent>

                  <TabsContent value="week" className="mt-0">
                    <div className="h-[400px] border rounded-md p-2">
                      <KLineChart timeframe="week" stockCode={params.code} />
                    </div>
                  </TabsContent>

                  <TabsContent value="month" className="mt-0">
                    <div className="h-[400px] border rounded-md p-2">
                      <KLineChart timeframe="month" stockCode={params.code} />
                    </div>
                  </TabsContent>

                  <TabsContent value="quarter" className="mt-0">
                    <div className="h-[400px] border rounded-md p-2">
                      <KLineChart timeframe="quarter" stockCode={params.code} />
                    </div>
                  </TabsContent>

                  <TabsContent value="year" className="mt-0">
                    <div className="h-[400px] border rounded-md p-2">
                      <KLineChart timeframe="year" stockCode={params.code} />
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>

            <Tabs defaultValue="info" className="mb-6">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="info">基本信息</TabsTrigger>
                <TabsTrigger value="news">相关新闻</TabsTrigger>
                <TabsTrigger value="analysis">分析报告</TabsTrigger>
                <TabsTrigger value="knowledge">知识图谱</TabsTrigger>
              </TabsList>

              <TabsContent value="info" className="mt-4">
                <Card>
                  <CardHeader>
                    <CardTitle>公司基本信息</CardTitle>
                    <CardDescription>
                      {stockData.name}({stockData.code})的基本信息和财务数据
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <StockInfo stockCode={params.code} />
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="news" className="mt-4">
                <Card>
                  <CardHeader>
                    <CardTitle>相关新闻</CardTitle>
                    <CardDescription>{stockData.name}的最新新闻和公告</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <StockNews stockCode={params.code} />
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" className="w-full">
                      查看更多新闻
                    </Button>
                  </CardFooter>
                </Card>
              </TabsContent>

              <TabsContent value="analysis" className="mt-4">
                <Card>
                  <CardHeader>
                    <CardTitle>分析报告</CardTitle>
                    <CardDescription>{stockData.name}的专业分析报告和研究</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <StockAnalysis stockCode={params.code} />
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" className="w-full">
                      查看更多分析
                    </Button>
                  </CardFooter>
                </Card>
              </TabsContent>

              <TabsContent value="knowledge" className="mt-4">
                <Card>
                  <CardHeader>
                    <CardTitle>知识图谱</CardTitle>
                    <CardDescription>{stockData.name}的关联信息可视化</CardDescription>
                  </CardHeader>
                  <CardContent className="h-[500px]">
                    <KnowledgeGraph stockCode={params.code} />
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" className="w-full">
                      展开完整图谱
                    </Button>
                  </CardFooter>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          <div>
            <Card className="mb-6">
              <CardHeader>
                <CardTitle className="flex items-center text-lg">
                  <Zap className="mr-2 h-5 w-5 text-yellow-500" />
                  AI智能诊断
                </CardTitle>
                <CardDescription>基于最新数据的AI分析</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="rounded-lg border p-3">
                    <h4 className="font-medium">投资建议</h4>
                    <div className="mt-2 grid grid-cols-3 gap-2 text-center text-sm">
                      <div className="rounded bg-green-100 p-2 text-green-700 font-medium">买入</div>
                      <div className="rounded bg-gray-100 p-2 text-gray-400">持有</div>
                      <div className="rounded bg-gray-100 p-2 text-gray-400">卖出</div>
                    </div>
                  </div>

                  <div className="rounded-lg border p-3">
                    <h4 className="font-medium">技术面评分</h4>
                    <div className="mt-2 flex items-center">
                      <div className="h-2 flex-1 rounded-full bg-gray-200">
                        <div className="h-2 w-[85%] rounded-full bg-green-500"></div>
                      </div>
                      <span className="ml-2 text-sm font-medium">85分</span>
                    </div>
                    <div className="mt-1 text-xs text-muted-foreground">MACD金叉，KDJ超买，量价配合良好</div>
                  </div>

                  <div className="rounded-lg border p-3">
                    <h4 className="font-medium">基本面评分</h4>
                    <div className="mt-2 flex items-center">
                      <div className="h-2 flex-1 rounded-full bg-gray-200">
                        <div className="h-2 w-[78%] rounded-full bg-green-500"></div>
                      </div>
                      <span className="ml-2 text-sm font-medium">78分</span>
                    </div>
                    <div className="mt-1 text-xs text-muted-foreground">业绩稳健增长，估值合理，行业龙头地位稳固</div>
                  </div>

                  <div className="rounded-lg border p-3">
                    <h4 className="font-medium">风险提示</h4>
                    <div className="mt-2 space-y-2 text-xs text-muted-foreground">
                      <p>• 行业政策变动可能影响公司业绩</p>
                      <p>• 市场竞争加剧可能导致利润率下降</p>
                      <p>• 宏观经济下行风险</p>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button className="w-full">获取完整AI分析报告</Button>
              </CardFooter>
            </Card>

            <Card className="mb-6">
              <CardHeader>
                <CardTitle className="flex items-center text-lg">
                  <Users className="mr-2 h-5 w-5 text-blue-500" />
                  机构持仓
                </CardTitle>
                <CardDescription>主要机构投资者持股情况</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {[
                    { name: "易方达基金", shares: "3,245万股", ratio: "2.34%", change: "+0.2%" },
                    { name: "中国人寿", shares: "2,890万股", ratio: "2.08%", change: "+0.1%" },
                    { name: "高瓴资本", shares: "2,560万股", ratio: "1.85%", change: "-0.3%" },
                    { name: "社保基金", shares: "2,120万股", ratio: "1.53%", change: "0.0%" },
                    { name: "挪威主权基金", shares: "1,780万股", ratio: "1.28%", change: "+0.4%" },
                  ].map((item, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <div>
                        <div className="font-medium">{item.name}</div>
                        <div className="text-xs text-muted-foreground">
                          {item.shares} ({item.ratio})
                        </div>
                      </div>
                      <div
                        className={
                          item.change.startsWith("+")
                            ? "text-green-500"
                            : item.change === "0.0%"
                              ? "text-gray-500"
                              : "text-red-500"
                        }
                      >
                        {item.change}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full">
                  查看全部机构持仓
                </Button>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center text-lg">
                  <BarChart3 className="mr-2 h-5 w-5 text-purple-500" />
                  同行业对比
                </CardTitle>
                <CardDescription>与行业内其他公司的对比</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="mb-1 flex items-center justify-between text-sm">
                      <span>市盈率</span>
                      <span className="text-muted-foreground">行业平均: 28.5</span>
                    </div>
                    <div className="h-2 w-full rounded-full bg-gray-200">
                      <div className="h-2 w-[65%] rounded-full bg-purple-500"></div>
                    </div>
                    <div className="mt-1 text-xs text-muted-foreground text-right">
                      {stockData.pe} (高于行业平均14%)
                    </div>
                  </div>

                  <div>
                    <div className="mb-1 flex items-center justify-between text-sm">
                      <span>净利润增长率</span>
                      <span className="text-muted-foreground">行业平均: 15.2%</span>
                    </div>
                    <div className="h-2 w-full rounded-full bg-gray-200">
                      <div className="h-2 w-[85%] rounded-full bg-purple-500"></div>
                    </div>
                    <div className="mt-1 text-xs text-muted-foreground text-right">23.5% (高于行业平均54%)</div>
                  </div>

                  <div>
                    <div className="mb-1 flex items-center justify-between text-sm">
                      <span>毛利率</span>
                      <span className="text-muted-foreground">行业平均: 42.8%</span>
                    </div>
                    <div className="h-2 w-full rounded-full bg-gray-200">
                      <div className="h-2 w-[95%] rounded-full bg-purple-500"></div>
                    </div>
                    <div className="mt-1 text-xs text-muted-foreground text-right">78.6% (高于行业平均83%)</div>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full">
                  查看完整对比报告
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}

