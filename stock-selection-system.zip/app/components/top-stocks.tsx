"use client"

import { useState } from "react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ArrowRight, ChevronDown } from "lucide-react"
import Link from "next/link"

export function TopStocks() {
  const [sortBy, setSortBy] = useState<"rank" | "change">("rank")

  const stocks = [
    { code: "600519", name: "贵州茅台", price: "1892.50", change: "+2.5%", rank: 1 },
    { code: "300750", name: "宁德时代", price: "187.65", change: "+3.8%", rank: 2 },
    { code: "601318", name: "中国平安", price: "48.92", change: "+1.2%", rank: 3 },
    { code: "600036", name: "招商银行", price: "42.56", change: "+2.3%", rank: 4 },
    { code: "000858", name: "五粮液", price: "168.75", change: "+1.8%", rank: 5 },
    { code: "601899", name: "紫金矿业", price: "10.25", change: "+4.2%", rank: 6 },
    { code: "600276", name: "恒瑞医药", price: "32.18", change: "+0.8%", rank: 7 },
    { code: "002594", name: "比亚迪", price: "245.30", change: "+3.5%", rank: 8 },
    { code: "601888", name: "中国中免", price: "158.40", change: "+1.5%", rank: 9 },
    { code: "600309", name: "万华化学", price: "78.65", change: "+2.1%", rank: 10 },
  ]

  const sortedStocks = [...stocks].sort((a, b) => {
    if (sortBy === "rank") {
      return a.rank - b.rank
    } else {
      return (
        Number.parseFloat(b.change.replace("+", "").replace("%", "")) -
        Number.parseFloat(a.change.replace("+", "").replace("%", ""))
      )
    }
  })

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between text-sm">
        <Button
          variant="ghost"
          size="sm"
          className={sortBy === "rank" ? "text-primary" : "text-muted-foreground"}
          onClick={() => setSortBy("rank")}
        >
          排名 {sortBy === "rank" && <ChevronDown className="ml-1 h-4 w-4" />}
        </Button>
        <Button
          variant="ghost"
          size="sm"
          className={sortBy === "change" ? "text-primary" : "text-muted-foreground"}
          onClick={() => setSortBy("change")}
        >
          涨幅 {sortBy === "change" && <ChevronDown className="ml-1 h-4 w-4" />}
        </Button>
      </div>

      <div className="space-y-3">
        {sortedStocks.map((stock, index) => (
          <Link
            href={`/stocks/${stock.code}`}
            key={stock.code}
            className="flex items-center justify-between hover:bg-muted/50 p-1.5 rounded-md transition-colors"
          >
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="w-6 h-6 flex items-center justify-center p-0">
                {stock.rank}
              </Badge>
              <div>
                <div className="font-medium">{stock.name}</div>
                <div className="text-xs text-muted-foreground">{stock.code}</div>
              </div>
            </div>
            <div className="text-right">
              <div className="font-medium">{stock.price}</div>
              <div className="text-xs text-green-500">{stock.change}</div>
            </div>
          </Link>
        ))}
      </div>

      <Button variant="link" size="sm" className="w-full mt-2">
        查看更多 <ArrowRight className="ml-1 h-4 w-4" />
      </Button>
    </div>
  )
}

