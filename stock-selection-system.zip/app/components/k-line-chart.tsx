"use client"

import { useEffect, useRef, useState } from "react"
import { Button } from "@/components/ui/button"
import { CandlestickChart, LineChart, BarChart3, Maximize2, Minimize2 } from "lucide-react"

interface KLineChartProps {
  timeframe: "day" | "week" | "month" | "quarter" | "year"
  stockCode: string
}

export function KLineChart({ timeframe, stockCode }: KLineChartProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [chartType, setChartType] = useState<"candle" | "line" | "volume">("candle")
  const [isFullscreen, setIsFullscreen] = useState(false)

  // 生成模拟K线数据
  const generateKLineData = (days: number) => {
    const data = []
    let price = stockCode === "600519" ? 1800 : stockCode === "300750" ? 180 : stockCode === "601318" ? 45 : 100

    for (let i = 0; i < days; i++) {
      const open = price
      const close = open * (1 + (Math.random() * 0.06 - 0.03))
      const high = Math.max(open, close) * (1 + Math.random() * 0.02)
      const low = Math.min(open, close) * (1 - Math.random() * 0.02)
      const volume = Math.floor(Math.random() * 10000) + 5000

      data.push({
        date: new Date(Date.now() - (days - i) * 24 * 60 * 60 * 1000),
        open,
        high,
        low,
        close,
        volume,
      })

      price = close
    }

    return data
  }

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // 设置画布尺寸
    const dpr = window.devicePixelRatio || 1
    const rect = canvas.getBoundingClientRect()
    canvas.width = rect.width * dpr
    canvas.height = rect.height * dpr
    ctx.scale(dpr, dpr)

    // 根据时间周期生成不同数量的K线
    const daysMap = {
      day: 30,
      week: 20,
      month: 24,
      quarter: 12,
      year: 12,
    }

    const data = generateKLineData(daysMap[timeframe])

    // 清空画布
    ctx.clearRect(0, 0, rect.width, rect.height)

    // 计算图表区域
    const padding = { top: 20, right: 50, bottom: 30, left: 50 }
    const chartWidth = rect.width - padding.left - padding.right
    const chartHeight = rect.height - padding.top - padding.bottom

    // 找出最高价和最低价
    const maxPrice = Math.max(...data.map((d) => d.high))
    const minPrice = Math.min(...data.map((d) => d.low))
    const priceRange = maxPrice - minPrice

    // 找出最大成交量
    const maxVolume = Math.max(...data.map((d) => d.volume))

    // 绘制坐标轴
    ctx.strokeStyle = "#e2e8f0"
    ctx.beginPath()
    ctx.moveTo(padding.left, padding.top)
    ctx.lineTo(padding.left, rect.height - padding.bottom)
    ctx.lineTo(rect.width - padding.right, rect.height - padding.bottom)
    ctx.stroke()

    // 绘制价格刻度
    ctx.fillStyle = "#64748b"
    ctx.font = "10px sans-serif"
    ctx.textAlign = "right"

    const priceStep = priceRange / 5
    for (let i = 0; i <= 5; i++) {
      const price = minPrice + priceStep * i
      const y = padding.top + chartHeight - (chartHeight * (price - minPrice)) / priceRange

      ctx.beginPath()
      ctx.moveTo(padding.left - 5, y)
      ctx.lineTo(padding.left, y)
      ctx.stroke()

      ctx.fillText(price.toFixed(2), padding.left - 8, y + 3)

      // 绘制水平网格线
      ctx.strokeStyle = "#e2e8f0"
      ctx.setLineDash([2, 2])
      ctx.beginPath()
      ctx.moveTo(padding.left, y)
      ctx.lineTo(rect.width - padding.right, y)
      ctx.stroke()
      ctx.setLineDash([])
    }

    // 绘制日期刻度
    ctx.textAlign = "center"
    const dateStep = Math.ceil(data.length / 6)
    for (let i = 0; i < data.length; i += dateStep) {
      const x = padding.left + (i * chartWidth) / (data.length - 1)
      const date = data[i].date

      ctx.beginPath()
      ctx.moveTo(x, rect.height - padding.bottom)
      ctx.lineTo(x, rect.height - padding.bottom + 5)
      ctx.stroke()

      let dateLabel
      if (timeframe === "day") {
        dateLabel = `${date.getMonth() + 1}/${date.getDate()}`
      } else if (timeframe === "week" || timeframe === "month") {
        dateLabel = `${date.getMonth() + 1}月`
      } else {
        dateLabel = `${date.getFullYear()}`
      }

      ctx.fillText(dateLabel, x, rect.height - padding.bottom + 15)

      // 绘制垂直网格线
      ctx.strokeStyle = "#e2e8f0"
      ctx.setLineDash([2, 2])
      ctx.beginPath()
      ctx.moveTo(x, padding.top)
      ctx.lineTo(x, rect.height - padding.bottom)
      ctx.stroke()
      ctx.setLineDash([])
    }

    // 根据图表类型绘制
    if (chartType === "candle") {
      // 绘制K线图
      const candleWidth = Math.min((chartWidth / data.length) * 0.8, 15)

      for (let i = 0; i < data.length; i++) {
        const d = data[i]
        const x = padding.left + (i * chartWidth) / (data.length - 1)

        const openY = padding.top + chartHeight - (chartHeight * (d.open - minPrice)) / priceRange
        const closeY = padding.top + chartHeight - (chartHeight * (d.close - minPrice)) / priceRange
        const highY = padding.top + chartHeight - (chartHeight * (d.high - minPrice)) / priceRange
        const lowY = padding.top + chartHeight - (chartHeight * (d.low - minPrice)) / priceRange

        // 绘制影线
        ctx.strokeStyle = d.close >= d.open ? "#22c55e" : "#ef4444"
        ctx.beginPath()
        ctx.moveTo(x, highY)
        ctx.lineTo(x, lowY)
        ctx.stroke()

        // 绘制实体
        ctx.fillStyle = d.close >= d.open ? "#22c55e" : "#ef4444"
        ctx.fillRect(x - candleWidth / 2, Math.min(openY, closeY), candleWidth, Math.abs(closeY - openY))
      }
    } else if (chartType === "line") {
      // 绘制折线图
      ctx.strokeStyle = "#3b82f6"
      ctx.lineWidth = 2
      ctx.beginPath()

      for (let i = 0; i < data.length; i++) {
        const d = data[i]
        const x = padding.left + (i * chartWidth) / (data.length - 1)
        const y = padding.top + chartHeight - (chartHeight * (d.close - minPrice)) / priceRange

        if (i === 0) {
          ctx.moveTo(x, y)
        } else {
          ctx.lineTo(x, y)
        }
      }

      ctx.stroke()

      // 添加渐变填充
      const gradient = ctx.createLinearGradient(0, padding.top, 0, rect.height - padding.bottom)
      gradient.addColorStop(0, "rgba(59, 130, 246, 0.2)")
      gradient.addColorStop(1, "rgba(59, 130, 246, 0)")

      ctx.fillStyle = gradient
      ctx.lineTo(padding.left + chartWidth, rect.height - padding.bottom)
      ctx.lineTo(padding.left, rect.height - padding.bottom)
      ctx.closePath()
      ctx.fill()
    } else if (chartType === "volume") {
      // 绘制成交量图
      const barWidth = Math.min((chartWidth / data.length) * 0.8, 15)

      for (let i = 0; i < data.length; i++) {
        const d = data[i]
        const x = padding.left + (i * chartWidth) / (data.length - 1)
        const volumeHeight = ((chartHeight * d.volume) / maxVolume) * 0.7 // 使用70%的高度显示成交量

        ctx.fillStyle = d.close >= d.open ? "rgba(34, 197, 94, 0.7)" : "rgba(239, 68, 68, 0.7)"
        ctx.fillRect(x - barWidth / 2, rect.height - padding.bottom - volumeHeight, barWidth, volumeHeight)
      }

      // 在上方绘制收盘价折线
      ctx.strokeStyle = "#3b82f6"
      ctx.lineWidth = 2
      ctx.beginPath()

      for (let i = 0; i < data.length; i++) {
        const d = data[i]
        const x = padding.left + (i * chartWidth) / (data.length - 1)
        // 使用上方30%的空间绘制价格线
        const priceAreaHeight = chartHeight * 0.3
        const y = padding.top + (priceAreaHeight - (priceAreaHeight * (d.close - minPrice)) / priceRange)

        if (i === 0) {
          ctx.moveTo(x, y)
        } else {
          ctx.lineTo(x, y)
        }
      }

      ctx.stroke()
    }
  }, [timeframe, chartType, stockCode])

  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen)
  }

  return (
    <div className={`relative ${isFullscreen ? "fixed inset-0 z-50 bg-background p-4" : ""}`}>
      <div className="flex justify-between items-center mb-2">
        <div className="flex space-x-1">
          <Button
            variant={chartType === "candle" ? "default" : "outline"}
            size="sm"
            onClick={() => setChartType("candle")}
          >
            <CandlestickChart className="h-4 w-4" />
          </Button>
          <Button variant={chartType === "line" ? "default" : "outline"} size="sm" onClick={() => setChartType("line")}>
            <LineChart className="h-4 w-4" />
          </Button>
          <Button
            variant={chartType === "volume" ? "default" : "outline"}
            size="sm"
            onClick={() => setChartType("volume")}
          >
            <BarChart3 className="h-4 w-4" />
          </Button>
        </div>
        <Button variant="ghost" size="sm" onClick={toggleFullscreen}>
          {isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
        </Button>
      </div>
      <canvas ref={canvasRef} className="w-full h-full" />
    </div>
  )
}

