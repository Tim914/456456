"use client"

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar, FileText, Info, Users } from "lucide-react"

interface StockInfoProps {
  stockCode: string
}

export function StockInfo({ stockCode }: StockInfoProps) {
  // 根据股票代码获取不同的模拟数据
  const getCompanyInfo = () => {
    if (stockCode === "600519") {
      return {
        name: "贵州茅台",
        fullName: "贵州茅台酒股份有限公司",
        industry: "白酒",
        established: "1999-11-20",
        listingDate: "2001-08-27",
        registeredCapital: "125,619.78万元",
        employees: "26,854人",
        headquarters: "贵州省仁怀市茅台镇",
        website: "www.moutaichina.com",
        businessScope: "茅台酒系列产品的生产与销售；饮料、食品、包装材料的生产与销售；防伪技术开发与运用。",
        description:
          "贵州茅台是中国特大型白酒上市公司，专业生产茅台酒系列产品，是中国最负盛名的白酒品牌之一。公司主要产品包括茅台酒、系列酒等。",
      }
    } else if (stockCode === "300750") {
      return {
        name: "宁德时代",
        fullName: "宁德时代新能源科技股份有限公司",
        industry: "电池制造",
        established: "2011-12-16",
        listingDate: "2018-06-11",
        registeredCapital: "243,772.60万元",
        employees: "91,392人",
        headquarters: "福建省宁德市蕉城区漳湾镇新港路2号",
        website: "www.catl.com",
        businessScope:
          "锂离子电池、锂聚合物电池、燃料电池、动力电池、超大容量储能电池、超级电容器、电池管理系统及可充电电池包、风光电储能系统、相关设备仪器的开发、生产和销售及售后服务。",
        description:
          "宁德时代是全球领先的锂离子电池制造商，专注于新能源汽车动力电池系统、储能系统的研发、生产和销售，致力于为全球新能源应用提供一流解决方案。",
      }
    } else if (stockCode === "601318") {
      return {
        name: "中国平安",
        fullName: "中国平安保险(集团)股份有限公司",
        industry: "保险",
        established: "1988-03-21",
        listingDate: "2007-03-01",
        registeredCapital: "1,828,024.14万元",
        employees: "362,035人",
        headquarters: "广东省深圳市福田区益田路5033号平安金融中心",
        website: "www.pingan.com",
        businessScope:
          "投资保险企业；监督管理控股投资企业的各种国内、国际业务；开展保险资金运用业务；经批准开展国内、国际保险业务；经中国保险监督管理委员会及国家有关部门批准的其他业务。",
        description:
          "中国平安是中国第一家股份制保险企业，业务范围涵盖保险、银行、资产管理等多个金融领域，是国内领先的个人金融生活服务集团。",
      }
    } else {
      return {
        name: "未知公司",
        fullName: "未知公司全称",
        industry: "未知行业",
        established: "未知",
        listingDate: "未知",
        registeredCapital: "未知",
        employees: "未知",
        headquarters: "未知",
        website: "未知",
        businessScope: "未知",
        description: "暂无公司描述信息",
      }
    }
  }

  const getFinancialData = () => {
    if (stockCode === "600519") {
      return {
        revenue: [
          { year: "2023", value: "1,252.34亿元", growth: "+12.3%" },
          { year: "2022", value: "1,115.23亿元", growth: "+17.8%" },
          { year: "2021", value: "946.51亿元", growth: "+11.2%" },
          { year: "2020", value: "851.16亿元", growth: "+10.3%" },
        ],
        netProfit: [
          { year: "2023", value: "625.78亿元", growth: "+13.1%" },
          { year: "2022", value: "553.12亿元", growth: "+19.2%" },
          { year: "2021", value: "464.13亿元", growth: "+12.5%" },
          { year: "2020", value: "412.47亿元", growth: "+13.3%" },
        ],
        eps: [
          { year: "2023", value: "49.82元", growth: "+13.1%" },
          { year: "2022", value: "44.05元", growth: "+19.2%" },
          { year: "2021", value: "36.96元", growth: "+12.5%" },
          { year: "2020", value: "32.85元", growth: "+13.3%" },
        ],
        roe: [
          { year: "2023", value: "32.5%", growth: "+0.8%" },
          { year: "2022", value: "31.7%", growth: "+1.2%" },
          { year: "2021", value: "30.5%", growth: "-0.3%" },
          { year: "2020", value: "30.8%", growth: "+0.5%" },
        ],
      }
    } else if (stockCode === "300750") {
      return {
        revenue: [
          { year: "2023", value: "4,285.76亿元", growth: "+22.6%" },
          { year: "2022", value: "3,495.89亿元", growth: "+152.1%" },
          { year: "2021", value: "1,386.59亿元", growth: "+159.1%" },
          { year: "2020", value: "535.16亿元", growth: "+9.9%" },
        ],
        netProfit: [
          { year: "2023", value: "445.89亿元", growth: "+10.3%" },
          { year: "2022", value: "404.17亿元", growth: "+92.9%" },
          { year: "2021", value: "209.52亿元", growth: "+185.3%" },
          { year: "2020", value: "73.44亿元", growth: "+22.4%" },
        ],
        eps: [
          { year: "2023", value: "1.83元", growth: "+10.3%" },
          { year: "2022", value: "1.66元", growth: "+92.9%" },
          { year: "2021", value: "0.86元", growth: "+185.3%" },
          { year: "2020", value: "0.30元", growth: "+22.4%" },
        ],
        roe: [
          { year: "2023", value: "15.8%", growth: "-2.1%" },
          { year: "2022", value: "17.9%", growth: "+2.5%" },
          { year: "2021", value: "15.4%", growth: "+5.6%" },
          { year: "2020", value: "9.8%", growth: "-1.2%" },
        ],
      }
    } else if (stockCode === "601318") {
      return {
        revenue: [
          { year: "2023", value: "11,852.34亿元", growth: "+5.8%" },
          { year: "2022", value: "11,205.68亿元", growth: "+8.3%" },
          { year: "2021", value: "10,346.12亿元", growth: "+6.9%" },
          { year: "2020", value: "9,677.45亿元", growth: "+4.2%" },
        ],
        netProfit: [
          { year: "2023", value: "1,435.67亿元", growth: "+3.2%" },
          { year: "2022", value: "1,392.07亿元", growth: "+6.9%" },
          { year: "2021", value: "1,301.47亿元", growth: "+18.9%" },
          { year: "2020", value: "1,094.53亿元", growth: "-4.2%" },
        ],
        eps: [
          { year: "2023", value: "8.12元", growth: "+3.2%" },
          { year: "2022", value: "7.87元", growth: "+6.9%" },
          { year: "2021", value: "7.36元", growth: "+18.9%" },
          { year: "2020", value: "6.19元", growth: "-4.2%" },
        ],
        roe: [
          { year: "2023", value: "8.2%", growth: "-0.3%" },
          { year: "2022", value: "8.5%", growth: "+0.4%" },
          { year: "2021", value: "8.1%", growth: "+1.2%" },
          { year: "2020", value: "6.9%", growth: "-1.5%" },
        ],
      }
    } else {
      return {
        revenue: [
          { year: "2023", value: "未知", growth: "未知" },
          { year: "2022", value: "未知", growth: "未知" },
          { year: "2021", value: "未知", growth: "未知" },
          { year: "2020", value: "未知", growth: "未知" },
        ],
        netProfit: [
          { year: "2023", value: "未知", growth: "未知" },
          { year: "2022", value: "未知", growth: "未知" },
          { year: "2021", value: "未知", growth: "未知" },
          { year: "2020", value: "未知", growth: "未知" },
        ],
        eps: [
          { year: "2023", value: "未知", growth: "未知" },
          { year: "2022", value: "未知", growth: "未知" },
          { year: "2021", value: "未知", growth: "未知" },
          { year: "2020", value: "未知", growth: "未知" },
        ],
        roe: [
          { year: "2023", value: "未知", growth: "未知" },
          { year: "2022", value: "未知", growth: "未知" },
          { year: "2021", value: "未知", growth: "未知" },
          { year: "2020", value: "未知", growth: "未知" },
        ],
      }
    }
  }

  const companyInfo = getCompanyInfo()
  const financialData = getFinancialData()

  return (
    <Tabs defaultValue="company">
      <TabsList className="grid w-full grid-cols-3">
        <TabsTrigger value="company">
          <Info className="h-4 w-4 mr-2" />
          公司简介
        </TabsTrigger>
        <TabsTrigger value="financial">
          <FileText className="h-4 w-4 mr-2" />
          财务数据
        </TabsTrigger>
        <TabsTrigger value="shareholders">
          <Users className="h-4 w-4 mr-2" />
          股东结构
        </TabsTrigger>
      </TabsList>

      <TabsContent value="company" className="mt-4">
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">公司全称</span>
                <span className="font-medium">{companyInfo.fullName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">所属行业</span>
                <Badge variant="outline">{companyInfo.industry}</Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">成立日期</span>
                <span>{companyInfo.established}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">上市日期</span>
                <span>{companyInfo.listingDate}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">注册资本</span>
                <span>{companyInfo.registeredCapital}</span>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">员工人数</span>
                <span>{companyInfo.employees}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">公司总部</span>
                <span>{companyInfo.headquarters}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">公司网站</span>
                <span className="text-primary">{companyInfo.website}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">股票代码</span>
                <span>{stockCode}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">交易所</span>
                <span>上海证券交易所</span>
              </div>
            </div>
          </div>

          <div>
            <h4 className="font-medium mb-2">经营范围</h4>
            <p className="text-sm text-muted-foreground">{companyInfo.businessScope}</p>
          </div>

          <div>
            <h4 className="font-medium mb-2">公司简介</h4>
            <p className="text-sm text-muted-foreground">{companyInfo.description}</p>
          </div>
        </div>
      </TabsContent>

      <TabsContent value="financial" className="mt-4">
        <div className="space-y-6">
          <Card>
            <CardContent className="p-4">
              <h4 className="font-medium mb-3 flex items-center">
                <Calendar className="h-4 w-4 mr-2" />
                营业收入(元)
              </h4>
              <div className="space-y-2">
                {financialData.revenue.map((item, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <div className="flex items-center">
                      <Badge variant="outline" className="mr-2">
                        {item.year}
                      </Badge>
                      <span>{item.value}</span>
                    </div>
                    <span className="text-green-500">{item.growth}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <h4 className="font-medium mb-3 flex items-center">
                <Calendar className="h-4 w-4 mr-2" />
                净利润(元)
              </h4>
              <div className="space-y-2">
                {financialData.netProfit.map((item, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <div className="flex items-center">
                      <Badge variant="outline" className="mr-2">
                        {item.year}
                      </Badge>
                      <span>{item.value}</span>
                    </div>
                    <span className="text-green-500">{item.growth}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardContent className="p-4">
                <h4 className="font-medium mb-3 flex items-center">
                  <Calendar className="h-4 w-4 mr-2" />
                  每股收益(元)
                </h4>
                <div className="space-y-2">
                  {financialData.eps.map((item, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <div className="flex items-center">
                        <Badge variant="outline" className="mr-2">
                          {item.year}
                        </Badge>
                        <span>{item.value}</span>
                      </div>
                      <span className="text-green-500">{item.growth}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <h4 className="font-medium mb-3 flex items-center">
                  <Calendar className="h-4 w-4 mr-2" />
                  净资产收益率(ROE)
                </h4>
                <div className="space-y-2">
                  {financialData.roe.map((item, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <div className="flex items-center">
                        <Badge variant="outline" className="mr-2">
                          {item.year}
                        </Badge>
                        <span>{item.value}</span>
                      </div>
                      <span className={item.growth.startsWith("+") ? "text-green-500" : "text-red-500"}>
                        {item.growth}
                      </span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </TabsContent>

      <TabsContent value="shareholders" className="mt-4">
        <div className="space-y-4">
          <div>
            <h4 className="font-medium mb-3">十大流通股东</h4>
            <div className="border rounded-md overflow-hidden">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-muted">
                  <tr>
                    <th
                      scope="col"
                      className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider"
                    >
                      股东名称
                    </th>
                    <th
                      scope="col"
                      className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider"
                    >
                      持股数量(万股)
                    </th>
                    <th
                      scope="col"
                      className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider"
                    >
                      持股比例
                    </th>
                    <th
                      scope="col"
                      className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider"
                    >
                      变动
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-background divide-y divide-gray-200">
                  {[
                    { name: "香港中央结算有限公司", shares: "8,945.23", ratio: "7.12%", change: "+0.23%" },
                    { name: "贵州茅台酒厂(集团)有限责任公司", shares: "6,789.45", ratio: "5.40%", change: "0.00%" },
                    { name: "中国证券金融股份有限公司", shares: "3,456.78", ratio: "2.75%", change: "-0.12%" },
                    { name: "中央汇金资产管理有限责任公司", shares: "2,345.67", ratio: "1.87%", change: "0.00%" },
                    { name: "易方达基金管理有限公司", shares: "1,987.65", ratio: "1.58%", change: "+0.34%" },
                    { name: "GIC PRIVATE LIMITED", shares: "1,654.32", ratio: "1.32%", change: "+0.08%" },
                    { name: "中国银行股份有限公司", shares: "1,432.10", ratio: "1.14%", change: "-0.05%" },
                    { name: "招商银行股份有限公司", shares: "1,234.56", ratio: "0.98%", change: "+0.12%" },
                    { name: "全国社保基金一零一组合", shares: "1,111.11", ratio: "0.88%", change: "+0.15%" },
                    { name: "中国工商银行股份有限公司", shares: "987.65", ratio: "0.79%", change: "-0.03%" },
                  ].map((item, index) => (
                    <tr key={index}>
                      <td className="px-4 py-2 whitespace-nowrap text-sm">{item.name}</td>
                      <td className="px-4 py-2 whitespace-nowrap text-sm">{item.shares}</td>
                      <td className="px-4 py-2 whitespace-nowrap text-sm">{item.ratio}</td>
                      <td
                        className={`px-4 py-2 whitespace-nowrap text-sm ${
                          item.change === "0.00%"
                            ? "text-gray-500"
                            : item.change.startsWith("+")
                              ? "text-green-500"
                              : "text-red-500"
                        }`}
                      >
                        {item.change}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div>
            <h4 className="font-medium mb-3">股东结构</h4>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-sm text-muted-foreground">国有股份</div>
                  <div className="text-2xl font-bold mt-2">58.3%</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-sm text-muted-foreground">外资持股</div>
                  <div className="text-2xl font-bold mt-2">12.5%</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-sm text-muted-foreground">机构持股</div>
                  <div className="text-2xl font-bold mt-2">21.8%</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-sm text-muted-foreground">个人持股</div>
                  <div className="text-2xl font-bold mt-2">7.4%</div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </TabsContent>
    </Tabs>
  )
}

