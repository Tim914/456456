import Link from "next/link"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  ArrowUp,
  BarChart3,
  BookOpen,
  ChevronRight,
  Globe,
  LineChart,
  Newspaper,
  Search,
  TrendingUp,
  Zap,
} from "lucide-react"
import { StockChart } from "./components/stock-chart"
import { TopStocks } from "./components/top-stocks"
import { IndustryTrends } from "./components/industry-trends"
import { NewsSection } from "./components/news-section"

export default function HomePage() {
  return (
    <div className="flex min-h-screen w-full flex-col">
      <header className="sticky top-0 z-50 flex h-16 items-center gap-4 border-b bg-background px-4 md:px-6">
        <Link href="/" className="flex items-center gap-2 font-semibold">
          <TrendingUp className="h-6 w-6 text-primary" />
          <span className="text-xl">来财智能选股系统</span>
        </Link>
        <div className="ml-auto flex items-center gap-4">
          <form className="relative hidden md:block">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <input
              type="search"
              placeholder="搜索股票..."
              className="rounded-md border border-input bg-background pl-8 pr-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            />
          </form>
          <Button variant="outline" size="sm" className="hidden md:flex">
            登录
          </Button>
          <Button size="sm" className="hidden md:flex">
            注册
          </Button>
          <Avatar className="h-9 w-9">
            <AvatarImage src="/placeholder.svg?height=36&width=36" alt="Avatar" />
            <AvatarFallback>用户</AvatarFallback>
          </Avatar>
        </div>
      </header>
      <main className="flex-1 p-4 md:p-6">
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">大盘指数</CardTitle>
              <CardDescription>上证指数</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">3,245.12</div>
              <div className="flex items-center text-sm text-green-500">
                <ArrowUp className="mr-1 h-4 w-4" />
                +1.2% <span className="text-muted-foreground ml-1">今日</span>
              </div>
              <div className="mt-3 h-[60px]">
                <StockChart />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">深证成指</CardTitle>
              <CardDescription>深圳成分指数</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">10,823.45</div>
              <div className="flex items-center text-sm text-green-500">
                <ArrowUp className="mr-1 h-4 w-4" />
                +0.8% <span className="text-muted-foreground ml-1">今日</span>
              </div>
              <div className="mt-3 h-[60px]">
                <StockChart />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">创业板指</CardTitle>
              <CardDescription>创业板指数</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">2,156.78</div>
              <div className="flex items-center text-sm text-red-500">
                <ArrowUp className="mr-1 h-4 w-4 rotate-180" />
                -0.3% <span className="text-muted-foreground ml-1">今日</span>
              </div>
              <div className="mt-3 h-[60px]">
                <StockChart negative={true} />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">科创50</CardTitle>
              <CardDescription>科创板50指数</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">1,078.92</div>
              <div className="flex items-center text-sm text-green-500">
                <ArrowUp className="mr-1 h-4 w-4" />
                +1.5% <span className="text-muted-foreground ml-1">今日</span>
              </div>
              <div className="mt-3 h-[60px]">
                <StockChart />
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="recommendations" className="mt-6">
          <TabsList className="grid w-full grid-cols-4 md:w-auto md:grid-cols-4">
            <TabsTrigger value="recommendations">推荐</TabsTrigger>
            <TabsTrigger value="industry">行业热点</TabsTrigger>
            <TabsTrigger value="ai">AI引擎</TabsTrigger>
            <TabsTrigger value="news">新闻速报</TabsTrigger>
          </TabsList>
          <TabsContent value="recommendations" className="mt-4">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center text-lg">
                    <Zap className="mr-2 h-5 w-5 text-yellow-500" />
                    Top 10 股票推荐
                  </CardTitle>
                  <CardDescription>基于市场表现和技术分析</CardDescription>
                </CardHeader>
                <CardContent>
                  <TopStocks />
                </CardContent>
                <CardFooter>
                  <Button variant="outline" className="w-full">
                    查看详情 <ChevronRight className="ml-1 h-4 w-4" />
                  </Button>
                </CardFooter>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center text-lg">
                    <BarChart3 className="mr-2 h-5 w-5 text-blue-500" />
                    个性化推荐
                  </CardTitle>
                  <CardDescription>根据您的投资偏好定制</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[
                      { code: "600036", name: "招商银行", price: "42.56", change: "+2.3%" },
                      { code: "000858", name: "五粮液", price: "168.75", change: "+1.2%" },
                      { code: "600276", name: "恒瑞医药", price: "32.18", change: "+0.8%" },
                      { code: "601318", name: "中国平安", price: "48.92", change: "-0.5%" },
                      { code: "600519", name: "贵州茅台", price: "1892.50", change: "+0.3%" },
                    ].map((stock, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <div>
                          <div className="font-medium">{stock.name}</div>
                          <div className="text-sm text-muted-foreground">{stock.code}</div>
                        </div>
                        <div className="text-right">
                          <div className="font-medium">{stock.price}</div>
                          <div className={stock.change.startsWith("+") ? "text-green-500" : "text-red-500"}>
                            {stock.change}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" className="w-full">
                    更新偏好 <ChevronRight className="ml-1 h-4 w-4" />
                  </Button>
                </CardFooter>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center text-lg">
                    <LineChart className="mr-2 h-5 w-5 text-green-500" />
                    市场热点
                  </CardTitle>
                  <CardDescription>近期表现强势的板块</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[
                      { name: "半导体", trend: "+5.2%", companies: "中芯国际, 韦尔股份, 北方华创" },
                      { name: "新能源", trend: "+3.8%", companies: "宁德时代, 比亚迪, 隆基绿能" },
                      { name: "人工智能", trend: "+4.5%", companies: "科大讯飞, 寒武纪, 商汤科技" },
                      { name: "医疗健康", trend: "+2.1%", companies: "迈瑞医疗, 爱尔眼科, 通策医疗" },
                      { name: "消费电子", trend: "+1.7%", companies: "立讯精密, 歌尔股份, 闻泰科技" },
                    ].map((sector, index) => (
                      <div key={index} className="space-y-1">
                        <div className="flex items-center justify-between">
                          <div className="font-medium">{sector.name}</div>
                          <Badge variant="outline" className="text-green-500">
                            {sector.trend}
                          </Badge>
                        </div>
                        <div className="text-sm text-muted-foreground">{sector.companies}</div>
                      </div>
                    ))}
                  </div>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" className="w-full">
                    板块分析 <ChevronRight className="ml-1 h-4 w-4" />
                  </Button>
                </CardFooter>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="industry" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle>行业热点分析</CardTitle>
                <CardDescription>各行业板块表现及热点追踪</CardDescription>
              </CardHeader>
              <CardContent>
                <IndustryTrends />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="ai" className="mt-4">
            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Zap className="mr-2 h-5 w-5 text-primary" />
                    AI投资引擎
                  </CardTitle>
                  <CardDescription>智能分析与预测</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="rounded-lg border p-3">
                      <h4 className="font-medium">市场情绪分析</h4>
                      <div className="mt-2 flex items-center">
                        <div className="h-2 flex-1 rounded-full bg-gray-200">
                          <div className="h-2 w-[65%] rounded-full bg-yellow-500"></div>
                        </div>
                        <span className="ml-2 text-sm">中性偏多</span>
                      </div>
                    </div>

                    <div className="rounded-lg border p-3">
                      <h4 className="font-medium">技术指标综合</h4>
                      <div className="mt-2 grid grid-cols-3 gap-2 text-center text-sm">
                        <div className="rounded bg-green-100 p-2 text-green-700">买入 (7)</div>
                        <div className="rounded bg-gray-100 p-2 text-gray-700">中性 (3)</div>
                        <div className="rounded bg-red-100 p-2 text-red-700">卖出 (2)</div>
                      </div>
                    </div>

                    <div className="rounded-lg border p-3">
                      <h4 className="font-medium">AI预测热点</h4>
                      <div className="mt-2 space-y-2">
                        {["半导体", "新能源汽车", "人工智能"].map((item, i) => (
                          <div key={i} className="flex items-center">
                            <Badge variant="secondary" className="mr-2">
                              {i + 1}
                            </Badge>
                            {item}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button className="w-full">获取AI深度分析报告</Button>
                </CardFooter>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Globe className="mr-2 h-5 w-5 text-primary" />
                    知识图谱
                  </CardTitle>
                  <CardDescription>股票关联信息可视化</CardDescription>
                </CardHeader>
                <CardContent className="h-[400px] flex items-center justify-center">
                  <div className="text-center">
                    <BookOpen className="mx-auto h-16 w-16 text-muted-foreground/50" />
                    <h3 className="mt-4 text-lg font-medium">知识图谱分析</h3>
                    <p className="mt-2 text-sm text-muted-foreground">
                      探索股票之间的关联、产业链上下游关系、
                      <br />
                      以及公司核心业务与市场趋势的联系
                    </p>
                    <Button className="mt-4">开始探索</Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="news" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Newspaper className="mr-2 h-5 w-5 text-primary" />
                  财经新闻速报
                </CardTitle>
                <CardDescription>今日重要财经新闻与公告</CardDescription>
              </CardHeader>
              <CardContent>
                <NewsSection />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

