"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Clock, ExternalLink } from "lucide-react"
import Link from "next/link"

export function NewsSection() {
  const [filter, setFilter] = useState<"all" | "market" | "company" | "policy">("all")

  const news = [
    {
      id: 1,
      title: "央行宣布降准0.5个百分点，释放长期资金约1万亿元",
      time: "今天 09:30",
      source: "央行网站",
      category: "policy",
      tags: ["央行", "降准", "货币政策"],
      isHot: true,
    },
    {
      id: 2,
      title: "宁德时代发布新一代电池技术，能量密度提升20%",
      time: "今天 10:15",
      source: "公司公告",
      category: "company",
      tags: ["宁德时代", "电池技术", "新能源"],
      isHot: true,
    },
    {
      id: 3,
      title: "美联储维持利率不变，暗示年内可能降息",
      time: "今天 08:00",
      source: "华尔街日报",
      category: "market",
      tags: ["美联储", "利率", "全球市场"],
      isHot: false,
    },
    {
      id: 4,
      title: "国家发改委：加快推进新型基础设施建设",
      time: "今天 11:30",
      source: "发改委网站",
      category: "policy",
      tags: ["发改委", "基础设施", "政策"],
      isHot: false,
    },
    {
      id: 5,
      title: "半导体行业Q2营收同比增长15.8%，超市场预期",
      time: "今天 09:45",
      source: "行业报告",
      category: "market",
      tags: ["半导体", "财报", "行业数据"],
      isHot: false,
    },
    {
      id: 6,
      title: "比亚迪发布2023年财报，净利润同比增长80.5%",
      time: "今天 08:30",
      source: "公司公告",
      category: "company",
      tags: ["比亚迪", "财报", "新能源汽车"],
      isHot: true,
    },
    {
      id: 7,
      title: "工信部：推动人工智能与实体经济深度融合",
      time: "今天 10:45",
      source: "工信部网站",
      category: "policy",
      tags: ["工信部", "人工智能", "实体经济"],
      isHot: false,
    },
    {
      id: 8,
      title: "A股三大指数集体收涨，创业板指涨2.3%",
      time: "昨天 15:00",
      source: "市场数据",
      category: "market",
      tags: ["A股", "指数", "创业板"],
      isHot: false,
    },
  ]

  const filteredNews = filter === "all" ? news : news.filter((item) => item.category === filter)

  return (
    <div className="space-y-4">
      <Tabs defaultValue="all" onValueChange={(value) => setFilter(value as any)}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="all">全部</TabsTrigger>
          <TabsTrigger value="market">市场动态</TabsTrigger>
          <TabsTrigger value="company">公司公告</TabsTrigger>
          <TabsTrigger value="policy">政策法规</TabsTrigger>
        </TabsList>
      </Tabs>

      <div className="space-y-4">
        {filteredNews.map((item) => (
          <Link
            href={`/news/${item.id}`}
            key={item.id}
            className="block border rounded-lg p-3 hover:bg-muted/50 transition-colors"
          >
            <div className="flex items-start justify-between">
              <h3 className="font-medium">
                {item.isHot && (
                  <Badge variant="secondary" className="mr-2 bg-red-100 text-red-700 hover:bg-red-100">
                    热门
                  </Badge>
                )}
                {item.title}
              </h3>
              <ExternalLink className="h-4 w-4 text-muted-foreground flex-shrink-0 ml-2" />
            </div>

            <div className="flex items-center mt-2 text-sm text-muted-foreground">
              <Clock className="h-3.5 w-3.5 mr-1" />
              <span>{item.time}</span>
              <span className="mx-2">·</span>
              <span>{item.source}</span>
            </div>

            <div className="flex items-center mt-2 flex-wrap gap-1">
              {item.tags.map((tag, idx) => (
                <Badge key={idx} variant="outline" className="text-xs font-normal">
                  {tag}
                </Badge>
              ))}
            </div>
          </Link>
        ))}
      </div>

      <Button variant="outline" className="w-full">
        加载更多
      </Button>
    </div>
  )
}

