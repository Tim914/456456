"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { ChevronRight } from "lucide-react"
import Link from "next/link"

export function IndustryTrends() {
  const [view, setView] = useState<"list" | "grid">("grid")

  const industries = [
    {
      name: "半导体",
      change: "+5.2%",
      companies: [
        { code: "688981", name: "中芯国际", price: "56.78", change: "+6.8%" },
        { code: "603501", name: "韦尔股份", price: "102.35", change: "+5.2%" },
        { code: "002371", name: "北方华创", price: "178.90", change: "+4.5%" },
      ],
      description: "受益于国产替代和AI芯片需求增长，半导体板块持续走强。",
    },
    {
      name: "新能源",
      change: "+3.8%",
      companies: [
        { code: "300750", name: "宁德时代", price: "187.65", change: "+3.8%" },
        { code: "002594", name: "比亚迪", price: "245.30", change: "+3.5%" },
        { code: "601012", name: "隆基绿能", price: "45.67", change: "+2.9%" },
      ],
      description: "新能源汽车销量持续增长，光伏产业链景气度提升。",
    },
    {
      name: "人工智能",
      change: "+4.5%",
      companies: [
        { code: "002230", name: "科大讯飞", price: "42.56", change: "+5.6%" },
        { code: "688256", name: "寒武纪", price: "68.90", change: "+4.2%" },
        { code: "688256", name: "商汤科技", price: "15.78", change: "+3.8%" },
      ],
      description: "大模型应用场景不断拓展，AI基础设施建设加速。",
    },
    {
      name: "医疗健康",
      change: "+2.1%",
      companies: [
        { code: "300760", name: "迈瑞医疗", price: "256.80", change: "+2.5%" },
        { code: "300015", name: "爱尔眼科", price: "32.45", change: "+1.8%" },
        { code: "600763", name: "通策医疗", price: "145.60", change: "+1.2%" },
      ],
      description: "医疗器械国产化进程加速，创新药研发取得突破。",
    },
    {
      name: "消费电子",
      change: "+1.7%",
      companies: [
        { code: "002475", name: "立讯精密", price: "38.25", change: "+2.3%" },
        { code: "002241", name: "歌尔股份", price: "25.67", change: "+1.5%" },
        { code: "600745", name: "闻泰科技", price: "78.90", change: "+1.2%" },
      ],
      description: "智能穿戴设备需求旺盛，手机产业链回暖。",
    },
    {
      name: "金融服务",
      change: "+1.5%",
      companies: [
        { code: "601318", name: "中国平安", price: "48.92", change: "+1.2%" },
        { code: "600036", name: "招商银行", price: "42.56", change: "+2.3%" },
        { code: "601398", name: "工商银行", price: "5.23", change: "+0.8%" },
      ],
      description: "银行业绩稳健增长，保险需求回升。",
    },
  ]

  return (
    <div className="space-y-6">
      <Tabs defaultValue="all" className="w-full">
        <TabsList className="grid grid-cols-4 md:w-auto md:grid-cols-6">
          <TabsTrigger value="all">全部</TabsTrigger>
          <TabsTrigger value="tech">科技</TabsTrigger>
          <TabsTrigger value="consumer">消费</TabsTrigger>
          <TabsTrigger value="finance">金融</TabsTrigger>
          <TabsTrigger value="energy">能源</TabsTrigger>
          <TabsTrigger value="health">医疗</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="mt-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {industries.map((industry, index) => (
              <Card key={index}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-lg font-semibold">{industry.name}</h3>
                    <Badge variant="outline" className="text-green-500">
                      {industry.change}
                    </Badge>
                  </div>

                  <p className="text-sm text-muted-foreground mb-4">{industry.description}</p>

                  <div className="space-y-2">
                    {industry.companies.map((company, idx) => (
                      <div key={idx} className="flex items-center justify-between text-sm">
                        <div className="flex items-center">
                          <span className="font-medium">{company.name}</span>
                          <span className="text-xs text-muted-foreground ml-1">({company.code})</span>
                        </div>
                        <div className="text-green-500">{company.change}</div>
                      </div>
                    ))}
                  </div>

                  <Link href={`/industry/${industry.name}`} className="flex items-center text-sm text-primary mt-3">
                    查看更多 <ChevronRight className="h-4 w-4" />
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Other tabs would have similar content but filtered */}
        <TabsContent value="tech" className="mt-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {industries
              .filter((industry) => ["半导体", "人工智能", "消费电子"].includes(industry.name))
              .map((industry, index) => (
                <Card key={index}>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="text-lg font-semibold">{industry.name}</h3>
                      <Badge variant="outline" className="text-green-500">
                        {industry.change}
                      </Badge>
                    </div>

                    <p className="text-sm text-muted-foreground mb-4">{industry.description}</p>

                    <div className="space-y-2">
                      {industry.companies.map((company, idx) => (
                        <div key={idx} className="flex items-center justify-between text-sm">
                          <div className="flex items-center">
                            <span className="font-medium">{company.name}</span>
                            <span className="text-xs text-muted-foreground ml-1">({company.code})</span>
                          </div>
                          <div className="text-green-500">{company.change}</div>
                        </div>
                      ))}
                    </div>

                    <Link href={`/industry/${industry.name}`} className="flex items-center text-sm text-primary mt-3">
                      查看更多 <ChevronRight className="h-4 w-4" />
                    </Link>
                  </CardContent>
                </Card>
              ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

