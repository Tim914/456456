"use client"

import { useEffect, useRef, useState } from "react"
import { Button } from "@/components/ui/button"
import { Maximize2, Minimize2, ZoomIn, ZoomOut } from "lucide-react"

interface KnowledgeGraphProps {
  stockCode: string
}

export function KnowledgeGraph({ stockCode }: KnowledgeGraphProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [zoom, setZoom] = useState(1)

  // 根据股票代码获取不同的知识图谱数据
  const getGraphData = () => {
    if (stockCode === "600519") {
      return {
        nodes: [
          { id: "center", label: "贵州茅台", type: "company", x: 0, y: 0 },
          { id: "parent", label: "贵州茅台集团", type: "company", x: -120, y: -100 },
          { id: "competitor1", label: "五粮液", type: "competitor", x: 150, y: -80 },
          { id: "competitor2", label: "洋河股份", type: "competitor", x: 180, y: 20 },
          { id: "competitor3", label: "泸州老窖", type: "competitor", x: 120, y: 100 },
          { id: "industry", label: "白酒行业", type: "industry", x: -150, y: 50 },
          { id: "supplier1", label: "高粱供应商", type: "supplier", x: -180, y: -30 },
          { id: "supplier2", label: "包装供应商", type: "supplier", x: -130, y: 120 },
          { id: "customer1", label: "经销商网络", type: "customer", x: 50, y: -150 },
          { id: "customer2", label: "商超渠道", type: "customer", x: -50, y: -150 },
          { id: "policy", label: "酒类政策", type: "policy", x: -200, y: 180 },
          { id: "tech", label: "酿酒工艺", type: "technology", x: 200, y: 150 },
        ],
        edges: [
          { from: "center", to: "parent", label: "子公司" },
          { from: "center", to: "competitor1", label: "竞争" },
          { from: "center", to: "competitor2", label: "竞争" },
          { from: "center", to: "competitor3", label: "竞争" },
          { from: "center", to: "industry", label: "属于" },
          { from: "supplier1", to: "center", label: "供应" },
          { from: "supplier2", to: "center", label: "供应" },
          { from: "center", to: "customer1", label: "销售" },
          { from: "center", to: "customer2", label: "销售" },
          { from: "policy", to: "industry", label: "影响" },
          { from: "center", to: "tech", label: "应用" },
        ],
      }
    } else if (stockCode === "300750") {
      return {
        nodes: [
          { id: "center", label: "宁德时代", type: "company", x: 0, y: 0 },
          { id: "customer1", label: "特斯拉", type: "customer", x: 150, y: -80 },
          { id: "customer2", label: "大众汽车", type: "customer", x: 180, y: 20 },
          { id: "customer3", label: "比亚迪", type: "customer", x: 120, y: 100 },
          { id: "industry", label: "动力电池行业", type: "industry", x: -150, y: 50 },
          { id: "competitor1", label: "LG新能源", type: "competitor", x: -120, y: -100 },
          { id: "competitor2", label: "三星SDI", type: "competitor", x: -180, y: -30 },
          { id: "supplier1", label: "锂矿供应商", type: "supplier", x: -130, y: 120 },
          { id: "supplier2", label: "电解液供应商", type: "supplier", x: 50, y: -150 },
          { id: "policy", label: "新能源政策", type: "policy", x: -200, y: 180 },
          { id: "tech1", label: "CTP技术", type: "technology", x: 200, y: 150 },
          { id: "tech2", label: "钠离子电池", type: "technology", x: -50, y: -150 },
        ],
        edges: [
          { from: "center", to: "customer1", label: "供应" },
          { from: "center", to: "customer2", label: "供应" },
          { from: "center", to: "customer3", label: "供应" },
          { from: "center", to: "industry", label: "属于" },
          { from: "center", to: "competitor1", label: "竞争" },
          { from: "center", to: "competitor2", label: "竞争" },
          { from: "supplier1", to: "center", label: "供应" },
          { from: "supplier2", to: "center", label: "供应" },
          { from: "policy", to: "industry", label: "影响" },
          { from: "center", to: "tech1", label: "研发" },
          { from: "center", to: "tech2", label: "研发" },
        ],
      }
    } else if (stockCode === "601318") {
      return {
        nodes: [
          { id: "center", label: "中国平安", type: "company", x: 0, y: 0 },
          { id: "subsidiary1", label: "平安银行", type: "subsidiary", x: 150, y: -80 },
          { id: "subsidiary2", label: "平安寿险", type: "subsidiary", x: 180, y: 20 },
          { id: "subsidiary3", label: "平安产险", type: "subsidiary", x: 120, y: 100 },
          { id: "subsidiary4", label: "平安资管", type: "subsidiary", x: 50, y: -150 },
          { id: "industry", label: "金融保险行业", type: "industry", x: -150, y: 50 },
          { id: "competitor1", label: "中国人寿", type: "competitor", x: -120, y: -100 },
          { id: "competitor2", label: "中国太保", type: "competitor", x: -180, y: -30 },
          { id: "customer", label: "个人与企业客户", type: "customer", x: -130, y: 120 },
          { id: "policy", label: "金融监管政策", type: "policy", x: -200, y: 180 },
          { id: "tech", label: "金融科技", type: "technology", x: 200, y: 150 },
          { id: "healthcare", label: "医疗健康", type: "industry", x: -50, y: -150 },
        ],
        edges: [
          { from: "center", to: "subsidiary1", label: "控股" },
          { from: "center", to: "subsidiary2", label: "控股" },
          { from: "center", to: "subsidiary3", label: "控股" },
          { from: "center", to: "subsidiary4", label: "控股" },
          { from: "center", to: "industry", label: "属于" },
          { from: "center", to: "competitor1", label: "竞争" },
          { from: "center", to: "competitor2", label: "竞争" },
          { from: "center", to: "customer", label: "服务" },
          { from: "policy", to: "industry", label: "影响" },
          { from: "center", to: "tech", label: "投资" },
          { from: "center", to: "healthcare", label: "布局" },
        ],
      }
    } else {
      return {
        nodes: [{ id: "center", label: "未知公司", type: "company", x: 0, y: 0 }],
        edges: [],
      }
    }
  }

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // 设置画布尺寸
    const dpr = window.devicePixelRatio || 1
    const rect = canvas.getBoundingClientRect()
    canvas.width = rect.width * dpr
    canvas.height = rect.height * dpr
    ctx.scale(dpr, dpr)

    // 获取图谱数据
    const graphData = getGraphData()

    // 清空画布
    ctx.clearRect(0, 0, rect.width, rect.height)

    // 计算中心点
    const centerX = rect.width / 2
    const centerY = rect.height / 2

    // 绘制边
    ctx.strokeStyle = "#e2e8f0"
    ctx.lineWidth = 1

    graphData.edges.forEach((edge) => {
      const fromNode = graphData.nodes.find((n) => n.id === edge.from)
      const toNode = graphData.nodes.find((n) => n.id === edge.to)

      if (fromNode && toNode) {
        const fromX = centerX + fromNode.x * zoom
        const fromY = centerY + fromNode.y * zoom
        const toX = centerX + toNode.x * zoom
        const toY = centerY + toNode.y * zoom

        // 计算方向向量
        const dx = toX - fromX
        const dy = toY - fromY
        const len = Math.sqrt(dx * dx + dy * dy)

        // 调整起点和终点，避免与节点重叠
        const nodeRadius = 25 * zoom
        const startX = fromX + (dx / len) * nodeRadius
        const startY = fromY + (dy / len) * nodeRadius
        const endX = toX - (dx / len) * nodeRadius
        const endY = toY - (dy / len) * nodeRadius

        // 绘制线条
        ctx.beginPath()
        ctx.moveTo(startX, startY)
        ctx.lineTo(endX, endY)
        ctx.stroke()

        // 绘制箭头
        const arrowSize = 5 * zoom
        const angle = Math.atan2(dy, dx)
        ctx.beginPath()
        ctx.moveTo(endX, endY)
        ctx.lineTo(endX - arrowSize * Math.cos(angle - Math.PI / 6), endY - arrowSize * Math.sin(angle - Math.PI / 6))
        ctx.lineTo(endX - arrowSize * Math.cos(angle + Math.PI / 6), endY - arrowSize * Math.sin(angle + Math.PI / 6))
        ctx.closePath()
        ctx.fillStyle = "#94a3b8"
        ctx.fill()

        // 绘制关系标签
        const labelX = (fromX + toX) / 2
        const labelY = (fromY + toY) / 2 - 10 * zoom
        ctx.fillStyle = "#64748b"
        ctx.font = `${12 * zoom}px sans-serif`
        ctx.textAlign = "center"
        ctx.fillText(edge.label, labelX, labelY)
      }
    })

    // 绘制节点
    graphData.nodes.forEach((node) => {
      const x = centerX + node.x * zoom
      const y = centerY + node.y * zoom
      const radius = 25 * zoom

      // 根据节点类型设置颜色
      let color
      switch (node.type) {
        case "company":
          color = "#3b82f6" // 蓝色
          break
        case "competitor":
          color = "#ef4444" // 红色
          break
        case "supplier":
          color = "#22c55e" // 绿色
          break
        case "customer":
          color = "#f59e0b" // 橙色
          break
        case "industry":
          color = "#8b5cf6" // 紫色
          break
        case "policy":
          color = "#64748b" // 灰色
          break
        case "technology":
          color = "#06b6d4" // 青色
          break
        case "subsidiary":
          color = "#ec4899" // 粉色
          break
        default:
          color = "#94a3b8"
      }

      // 绘制节点圆形
      ctx.beginPath()
      ctx.arc(x, y, radius, 0, Math.PI * 2)
      ctx.fillStyle = color + "20" // 添加透明度
      ctx.fill()
      ctx.strokeStyle = color
      ctx.lineWidth = 2 * zoom
      ctx.stroke()

      // 绘制节点标签
      ctx.fillStyle = "#1e293b"
      ctx.font = `${14 * zoom}px sans-serif`
      ctx.textAlign = "center"
      ctx.fillText(node.label, x, y + radius + 15 * zoom)
    })
  }, [zoom, stockCode, isFullscreen])

  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen)
  }

  const handleZoomIn = () => {
    setZoom((prev) => Math.min(prev + 0.2, 2))
  }

  const handleZoomOut = () => {
    setZoom((prev) => Math.max(prev - 0.2, 0.5))
  }

  return (
    <div className={`relative ${isFullscreen ? "fixed inset-0 z-50 bg-background p-4" : ""}`}>
      <div className="flex justify-end items-center mb-2 gap-2">
        <Button variant="outline" size="sm" onClick={handleZoomIn}>
          <ZoomIn className="h-4 w-4" />
        </Button>
        <Button variant="outline" size="sm" onClick={handleZoomOut}>
          <ZoomOut className="h-4 w-4" />
        </Button>
        <Button variant="outline" size="sm" onClick={toggleFullscreen}>
          {isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
        </Button>
      </div>
      <canvas ref={canvasRef} className="w-full h-full border rounded-md" />
      <div className="mt-2 text-xs text-muted-foreground">
        提示：点击"全屏"按钮可查看完整知识图谱，使用缩放按钮可调整视图大小
      </div>
    </div>
  )
}

